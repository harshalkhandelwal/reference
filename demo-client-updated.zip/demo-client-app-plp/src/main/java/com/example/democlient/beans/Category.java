package com.example.democlient.beans;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
