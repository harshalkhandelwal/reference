package com.capgemini.controller.DAO;

import java.util.*;

import com.capgemini.controller.dto.UserDTO;


//Follow TODOs (if available)
/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface userDAO 
{
    public boolean create(UserDTO car);
    public boolean validate();

}