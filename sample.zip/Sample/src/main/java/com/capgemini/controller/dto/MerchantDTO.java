package com.capgemini.controller.dto;

public class MerchantDTO extends UserDTO {

}
