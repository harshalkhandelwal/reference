package com.example.democlientappplp;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MerchantDTO {
	@Id
	private int merchantId;
	private String merchantName;
	private String address;
	private String storeName;
	private String mobileNo;
	
	public MerchantDTO() {
		super();
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	

}
