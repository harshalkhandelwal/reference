package com.capgemini.controller.dto;

public class CustomerDTO extends UserDTO {

}
