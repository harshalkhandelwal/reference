package com.example.democlientappplp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Response {
	@JsonProperty
	private CustomerDTO customerRef;;

	public CustomerDTO getRestResponse() {
		return customerRef;
	}

	public void setRestResponse(CustomerDTO restResponse) {
		customerRef = restResponse;
	}

	public Response() {
	}

	@Override
	public String toString() {
		return "Response [RestResponse=" + customerRef + "]";
	}
}
