package com.capgemini.controller.DAOImpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.controller.DAO.userDAO;
import com.capgemini.controller.dto.UserDTO;



@Repository
@Transactional
public class JPAUserDAO implements userDAO {

	@PersistenceContext
	private EntityManager entityManager;

	public JPAUserDAO() {
		System.out.println("JPAUserDAO instantiated...");
	}

	@Override
	@Transactional
	public boolean create(UserDTO user) {

		try {
			System.out.println("saving user details");
			entityManager.persist(user);
			entityManager.close();
			return true;

		} catch (RuntimeException e) {
			// tx.rollback();
			throw e;
		} finally {
			entityManager.close();
		}
	}

	@Override
	public boolean validate() {
		// TODO Auto-generated method stub
		return false;
	}

}
