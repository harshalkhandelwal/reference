package com.example.democlient.repo;

import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.democlient.beans.Merchant;
import com.example.democlient.beans.User;




//Follow TODOs (if available)
/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface userDAO extends JpaRepository<Merchant, Integer>
{
    public void create(User user);
    public boolean validate(User user);

}