package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.controller.DAO.userDAO;
import com.capgemini.controller.dto.UserDTO;

@RestController
@RequestMapping("/capStore")
public class UserActionsControllerHelper {


	@Autowired
	private userDAO userDAORef;
	private static final String ADD_USER_ACTION = "adduser";
	private static final String VALIDATEUSER_ACTION = "validateuser";


	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String AddUser(@ModelAttribute("user") UserDTO user, ModelMap map, @RequestParam(value = "action") String action,
			@RequestParam(value = "email") String[] emails) {
		String destinationPage = "login";
		if (action.equals(ADD_USER_ACTION)) {
		/*	if (userDAORef.findById(user.getId()) == null) {
				userDAORef.create(user);
			} */
		} 
		//List<UserDTO> cars = userDAORef.findAll();
		//map.addAttribute("carList", cars);

		return destinationPage;
	}
	
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String validate(@ModelAttribute("user") UserDTO user, ModelMap map, @RequestParam(value = "action") String action,
			@RequestParam(value = "email") String[] emails) {
		String destinationPage = "login";
		if (action.equals(ADD_USER_ACTION)) {
		/*	if (userDAORef.findById(user.getId()) == null) {
				userDAORef.create(user);
			} */
		} 
		//List<UserDTO> cars = userDAORef.findAll();
		//map.addAttribute("carList", cars);

		return destinationPage;
	}

	@ModelAttribute("user")
	public UserDTO createCar() {
		return new UserDTO();
	}

}
