package com.example.democlient.beans;

public enum SoftDelete {
	Activated, Deactivated
}
