package com.example.democlient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.example.democlient.beans.Merchant;
import com.example.democlient.beans.User;
import com.example.democlient.repo.userDAO;


@Controller
@RequestMapping("/controller")
public class WelcomeController {
	
	@Autowired
	userDAO userDAO;

	// inject via application.properties
	/*
	 * @Value("${welcome.message:test}") private String message = "Hello World";
	 * 
	 * @RequestMapping("/") public String welcome(Map<String, Object> model) {
	 * model.put("message", this.message); return "welcome"; }
	 */

	@RequestMapping(method=RequestMethod.GET,value="/login")
	public String getResponse(@ModelAttribute("user") User user)
	{

			//RestTemplate restTemplate = new RestTemplate(); 
		//	Response response = restTemplate.getForObject("http://localhost:8088/api/v1/response",Response.class);

			//System.out.println(response);
		//	map.addAttribute("message",response);
	
			return "login";
			
	}
	
	
	@RequestMapping(method=RequestMethod.GET ,value="/role")
     public String role() 
	{
		return "role";
	}
	
	@RequestMapping(method=RequestMethod.GET ,value="/registerMerchant")
    public String registerMerchant(@ModelAttribute("user") User user) 
	{
		//RestTemplate restTemplate = new RestTemplate(); 
		//userDAO.save(user);
		return "registerMerchant";
	}
	
	@RequestMapping(method=RequestMethod.GET ,value="/registerCustomer")
    public String registerCustomer(@ModelAttribute("user") User user) {
		return "registerCustomer";
	}
	
	@RequestMapping(method=RequestMethod.GET ,value="/forget")
    public String forget(@ModelAttribute("user") User user) {
		return "forget";
	}
	
/*	@ModelAttribute("merchant")
	public MerchantDTO createCar() {
		return new MerchantDTO();
	}*/
	
	@ModelAttribute("user")
	public Merchant createCar() {
		return new Merchant();
	}
}
