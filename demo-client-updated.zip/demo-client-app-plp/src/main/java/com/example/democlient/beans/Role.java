package com.example.democlient.beans;

public enum Role {
	Customer,Admin,Merchant
}
