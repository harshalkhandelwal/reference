package com.example.democlientappplp;

import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;



//Follow TODOs (if available)
/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface userDAO extends JpaRepository<MerchantDTO, Integer>
{
    public void create(UserDTO user);
    public boolean validate(UserDTO user);

}